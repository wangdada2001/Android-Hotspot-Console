#!/system/bin/sh
MODDIR=${0%/*}
/system/bin/sh "$MODDIR/control.sh" stop
# State belongs only to this module. No SMS or modem data is stored here.
rm -rf /data/adb/oneplus-hotspot

# Only root-owned public bridge code is staged outside the private data path.
rm -rf /data/misc/android_hotspot_console_sms
