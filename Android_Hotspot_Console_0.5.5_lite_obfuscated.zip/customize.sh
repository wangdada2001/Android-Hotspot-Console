#!/system/bin/sh
[ "$BOOTMODE" = true ] || abort "Install this module from the Magisk app, not recovery."
[ "$ARCH" = arm64 ] || abort "This package supports arm64 devices only."
[ "$API" -ge 29 ] || abort "Android 10 or newer is required."
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/bin/hotspotd" 0 0 0755
set_perm "$MODPATH/ethernet-bridge.jar" 0 0 0444
set_perm "$MODPATH/scrcpy-server.jar" 0 0 0444
for SCRIPT in service.sh action.sh control.sh uninstall.sh; do
  set_perm "$MODPATH/$SCRIPT" 0 0 0755
done
ui_print "- Android Hotspot Console 0.5.5"
# Lite keeps manual hotspot, forwarding and read-only cells; it excludes radio locks,
# automatic hotspot policies, screen mirroring and USB adapter auto-sharing.
# tools/build.py replaces the placeholder on the next line.
ui_print "- Lite: SMS forwarding, manual hotspot/clients and read-only serving/neighbor cells."
ui_print "- No SMS inbox/send/delete, hotspot automatic policy, RF locking or screen mirroring."
ui_print "- Terminal, traffic history, network settings, modules and plugins remain available."
ui_print "- Hotspot uses password access for all devices; legacy client restrictions are removed on startup."
# Take a rolling snapshot of the private state directory before this install re-runs
# --init and replaces the daemon. Traffic history, credentials and hotspot settings are
# worth more than the upgrade itself: if anything in the upgrade chain ever misreads a
# state file, the snapshot keeps the data recoverable by hand. A fresh install has
# nothing to copy and the cp is simply skipped. The snapshot lives outside both the
# module directory and the state directory, so even uninstalling leaves it behind.
if [ -d /data/adb/oneplus-hotspot ]; then
  SNAP=/data/adb/oneplus-hotspot-preupgrade
  rm -rf "$SNAP" 2>/dev/null
  cp -a /data/adb/oneplus-hotspot "$SNAP" 2>/dev/null || ui_print "- Pre-upgrade snapshot failed; existing data is left untouched."
fi
ui_print "- Creating private local login credentials..."
"$MODPATH/bin/hotspotd" --init || abort "Unable to initialize server. Installation stopped."
ui_print "- Read initial password with:"
ui_print "  su -c 'cat /data/adb/oneplus-hotspot/initial-password.txt'"
ui_print "- Reboot, unlock the phone, then open http://127.0.0.1:8080"
