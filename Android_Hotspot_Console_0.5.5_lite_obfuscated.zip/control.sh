#!/system/bin/sh
MODDIR=${0%/*}
STATE=/data/adb/oneplus-hotspot
BIN="$MODDIR/bin/hotspotd"
umask 077
[ "$(id -u)" = 0 ] || { echo "Root required"; exit 1; }
is_running() {
  PID=$(cat "$STATE/server.pid" 2>/dev/null)
  case "$PID" in ''|*[!0-9]*) return 1;; esac
  [ "$(readlink "/proc/$PID/exe" 2>/dev/null)" = "$BIN" ] && kill -0 "$PID" 2>/dev/null
}
stop_server() {
  if is_running; then
    kill "$PID" || return 1
    COUNT=0
    while is_running; do
      sleep 1
      COUNT=$((COUNT + 1))
      [ "$COUNT" -lt 5 ] || return 1
    done
  fi
  "$BIN" --cleanup-hotspot || echo "Some hotspot rate rules could not be removed; reboot to clear them. Set limits remain saved."
}
start_server() {
  if is_running; then echo "Already running"; return 0; fi
  [ -f "$MODDIR/disable" ] && { echo "Module is disabled"; return 1; }
  [ -f "$MODDIR/remove" ] && { echo "Module is pending removal"; return 1; }
  "$BIN" --init || return 1
  if [ -f "$STATE/service.log" ]; then mv "$STATE/service.log" "$STATE/service.previous.log"; fi
  "$BIN" >> "$STATE/service.log" 2>&1 < /dev/null &
  COUNT=0
  while ! is_running; do
    sleep 1
    COUNT=$((COUNT + 1))
    [ "$COUNT" -lt 25 ] || break
  done
  is_running || { echo "Start failed. Check $STATE/service.log"; return 1; }
  echo "Running. Phone: http://127.0.0.1:8080"
}
case "${1:-status}" in
  start) start_server;;
  stop) stop_server;;
  restart) stop_server && start_server;;
  status) if is_running; then echo "Running, PID=$PID"; else echo "Stopped"; fi;;
  reset-password) stop_server && "$BIN" --reset-password && start_server;;
  diagnose) "$BIN" --diagnose;;
  *) echo "Usage: control.sh start|stop|restart|status|reset-password|diagnose"; exit 1;;
esac
