#!/system/bin/sh
MODDIR=${0%/*}
COUNT=0
while [ "$(/system/bin/getprop sys.boot_completed)" != 1 ]; do
  sleep 3
  COUNT=$((COUNT + 1))
  [ "$COUNT" -lt 100 ] || exit 1
done
[ -e "$MODDIR/disable" ] && exit 0
[ -e "$MODDIR/remove" ] && exit 0
/system/bin/sh "$MODDIR/control.sh" start
