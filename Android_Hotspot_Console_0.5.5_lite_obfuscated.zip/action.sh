#!/system/bin/sh
MODDIR=${0%/*}
/system/bin/sh "$MODDIR/control.sh" start
if [ -f /data/adb/oneplus-hotspot/initial-password.txt ]; then
  echo "Initial management password:"
  cat /data/adb/oneplus-hotspot/initial-password.txt
else
  echo "Use the management password you set."
fi
echo "Opening http://127.0.0.1:8080"
/system/bin/am start -a android.intent.action.VIEW -d http://127.0.0.1:8080 >/dev/null 2>&1
